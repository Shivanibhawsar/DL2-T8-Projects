TEAM NAME- HACK_INVERSION
TEAM MEMEBERS-
 - NISHA SHARMA
 - PRIYANSHU PARIHAR
 - RANI MAHESHWARI 


IMAGE CAPTINONING
(use of gpu environment is required as neural network take alot of time to train)

To run the code-
1. Get your kaggle api through your kaggle account
    kaggle>my profile>api>generate new api token (downloads a json file)

2. upload this json file on Colab through drive else through runtime.
    for drive:
        from google.colab import drive
        drive.mount('/content/drive')
    upload on environment:
        colab>menu>upload file>choose .json file to upload
3. Now your api/dataset is ready to download data

Frequent error- Outdated api 
to resolve this (run below code):
--- !pip install --upgrade --force-reinstall --no-deps kaggle

Import the required libraries if cannot troubleshoot by
! pip install library name

DATASET:
Taken from:
url :- https://www.kaggle.com/shadabhussain/flickr8k
Dataset consist of-
Image file
caption(text file)

Sequential model is used for both training images and caption files.
